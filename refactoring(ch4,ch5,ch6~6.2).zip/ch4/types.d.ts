export interface IProducer {
    name: string;
    cost: number;
    production: number;
}